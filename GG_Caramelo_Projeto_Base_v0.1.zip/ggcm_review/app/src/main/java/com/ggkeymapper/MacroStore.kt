package com.ggkeymapper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class MacroStep(val x: Float, val y: Float, val delayMs: Long = 120L)
data class KeyMacro(val name: String, val triggerKeyCode: Int, val steps: List<MacroStep>)

/** Armazena macros criadas pelo usuário; não usa código nem recursos internos do APK de referência. */
object MacroStore {
    private const val PREFS = "gg_mapper_settings"
    private const val KEY_MACROS = "user_macros_v1"

    fun load(context: Context): List<KeyMacro> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MACROS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val stepArray = item.optJSONArray("steps") ?: JSONArray()
                    val steps = buildList {
                        for (j in 0 until stepArray.length()) {
                            val s = stepArray.getJSONObject(j)
                            add(MacroStep(s.optDouble("x", .5).toFloat().coerceIn(0f, 1f),
                                s.optDouble("y", .5).toFloat().coerceIn(0f, 1f),
                                s.optLong("delayMs", 120L).coerceIn(50L, 5000L)))
                        }
                    }
                    if (steps.isNotEmpty()) add(KeyMacro(item.optString("name", "Macro ${i + 1}"),
                        item.optInt("triggerKeyCode"), steps))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(context: Context, macros: List<KeyMacro>) {
        val arr = JSONArray()
        macros.forEach { macro ->
            val steps = JSONArray()
            macro.steps.forEach { step ->
                steps.put(JSONObject().put("x", step.x).put("y", step.y).put("delayMs", step.delayMs))
            }
            arr.put(JSONObject().put("name", macro.name)
                .put("triggerKeyCode", macro.triggerKeyCode).put("steps", steps))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_MACROS, arr.toString()).apply()
    }
}
