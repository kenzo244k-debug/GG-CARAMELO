package com.ggkeymapper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class KeyMapping(val keyCode: Int, val x: Float, val y: Float)

object MappingStore {
    private const val PREFS = "gg_mapper_settings"
    private const val KEY_MAPPINGS = "key_mappings"
    private const val KEY_PROFILE = "active_profile"
    private const val KEY_PRECISION_MODE = "precision_mode_enabled"

    fun isPrecisionModeEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_PRECISION_MODE, false)

    fun setPrecisionModeEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PRECISION_MODE, enabled).apply()
    }

    fun load(context: Context): MutableList<KeyMapping> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MAPPINGS, "[]") ?: "[]"
        val result = mutableListOf<KeyMapping>()
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                result.add(KeyMapping(
                    item.optInt("keyCode"),
                    item.optDouble("x", 0.5).toFloat().coerceIn(0f, 1f),
                    item.optDouble("y", 0.5).toFloat().coerceIn(0f, 1f)
                ))
            }
        } catch (_: Exception) {}
        return result
    }

    fun save(context: Context, mappings: List<KeyMapping>) {
        val array = JSONArray()
        mappings.forEach {
            array.put(JSONObject().put("keyCode", it.keyCode).put("x", it.x).put("y", it.y))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_MAPPINGS, array.toString()).apply()
    }

    fun saveProfile(context: Context, name: String, mappings: List<KeyMapping>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val profiles = try { JSONObject(prefs.getString("profiles", "{}") ?: "{}") }
            catch (_: Exception) { JSONObject() }
        val array = JSONArray()
        mappings.forEach {
            array.put(JSONObject().put("keyCode", it.keyCode).put("x", it.x).put("y", it.y))
        }
        profiles.put(name.ifBlank { "Padrão" }, array)
        prefs.edit().putString("profiles", profiles.toString())
            .putString(KEY_PROFILE, name.ifBlank { "Padrão" }).apply()
        save(context, mappings)
    }

    fun loadProfile(context: Context, name: String): MutableList<KeyMapping>? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return try {
            val profiles = JSONObject(prefs.getString("profiles", "{}") ?: "{}")
            val array = profiles.optJSONArray(name) ?: return null
            val result = mutableListOf<KeyMapping>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                result.add(KeyMapping(item.optInt("keyCode"),
                    item.optDouble("x", .5).toFloat(), item.optDouble("y", .5).toFloat()))
            }
            save(context, result)
            result
        } catch (_: Exception) { null }
    }

    fun profileNames(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("profiles", "{}") ?: "{}"
        return try {
            val names = mutableListOf<String>()
            val keys = JSONObject(raw).keys()
            while (keys.hasNext()) names.add(keys.next())
            names.sorted()
        } catch (_: Exception) { emptyList() }
    }
}
