package com.ggkeymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

/**
 * Recebe teclas físicas quando o usuário habilita este serviço nas configurações
 * de Acessibilidade. Cada tecla cadastrada dispara um toque na posição proporcional
 * configurada pelo usuário.
 */
class KeyMappingAccessibilityService : AccessibilityService() {
    private val macroHandler = Handler(Looper.getMainLooper())
    private var activeMacro: Runnable? = null
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        if (event.action == KeyEvent.ACTION_UP) {
            val macro = MacroStore.load(this).firstOrNull { it.triggerKeyCode == event.keyCode }
            if (macro != null) {
                activeMacro?.let { macroHandler.removeCallbacks(it) }
                activeMacro = null
                return true
            }
            return false
        }
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false

        val macro = MacroStore.load(this).firstOrNull { it.triggerKeyCode == event.keyCode }
        if (macro != null) {
            runMacro(macro)
            return true
        }
        val mapping = MappingStore.load(this).firstOrNull { it.keyCode == event.keyCode } ?: return false
        return dispatchTap(mapping.x, mapping.y)
    }

    private fun runMacro(macro: KeyMacro) {
        activeMacro?.let { macroHandler.removeCallbacks(it) }
        var index = 0
        val runner = object : Runnable {
            override fun run() {
                if (index >= macro.steps.size) { activeMacro = null; return }
                val step = macro.steps[index++]
                dispatchTap(step.x, step.y)
                if (index < macro.steps.size) {
                    macroHandler.postDelayed(this, step.delayMs)
                } else activeMacro = null
            }
        }
        activeMacro = runner
        macroHandler.post(runner)
    }

    private fun dispatchTap(normalizedX: Float, normalizedY: Float): Boolean {
        val metrics = resources.displayMetrics
        val precisionMode = MappingStore.isPrecisionModeEnabled(this)
        val rawX = normalizedX.coerceIn(0f, 1f) * metrics.widthPixels
        val rawY = normalizedY.coerceIn(0f, 1f) * metrics.heightPixels
        val x = if (precisionMode) rawX.roundToInt().toFloat() else rawX
        val y = if (precisionMode) rawY.roundToInt().toFloat() else rawY
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        activeMacro?.let { macroHandler.removeCallbacks(it) }
        activeMacro = null
        super.onDestroy()
    }
}
