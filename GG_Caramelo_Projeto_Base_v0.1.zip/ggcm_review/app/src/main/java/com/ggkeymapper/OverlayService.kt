package com.ggkeymapper

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var menu: View? = null
    private var crosshair: View? = null
    private val hudViews = mutableListOf<View>()
    private var hudVisible = false
    private val green = Color.rgb(217, 154, 69)
    private val bg = Color.rgb(30, 22, 16)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showBubble()
        if (MappingStore.load(this).isNotEmpty()) showHud()
    }

    private fun startAsForeground() {
        val channelId = "gg_mapper_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "GG CARAMELO", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        notification.setContentTitle("GG CARAMELO").setContentText("Controles flutuantes ativados")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true)
        startForeground(41, notification.build())
    }

    private fun params(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
    }

    private fun label(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(green)
        setPadding(18, 13, 18, 13); setBackgroundColor(bg)
    }

    private fun showBubble() {
        val b = label("GG", 18f).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(74, 48, 27), green, dp(29))
        }
        val lp = params().apply { width = dp(58); height = dp(58); x = 20; y = 160 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        b.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(); true }
                else -> true
            }
        }
        bubble = b
        wm.addView(b, lp)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(2), stroke)
        cornerRadius = radius.toFloat()
    }

    /** Desenha no overlay do sistema os marcadores guardados no editor HUD. */
    private fun showHud() {
        hideHud()
        val mappings = MappingStore.load(this)
        if (mappings.isEmpty()) {
            Toast.makeText(this, "Adicione e salve teclas no editor HUD primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        val metrics = resources.displayMetrics
        mappings.forEach { mapping ->
            val keyLabel = try { android.view.KeyEvent.keyCodeToString(mapping.keyCode).removePrefix("KEYCODE_") }
                catch (_: Exception) { mapping.keyCode.toString() }
            val marker = TextView(this).apply {
                text = keyLabel
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = rounded(Color.argb(205, 12, 32, 19), green, dp(24))
                elevation = dp(8).toFloat()
            }
            val lp = WindowManager.LayoutParams(
                dp(48), dp(48), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (mapping.x.coerceIn(0f, 1f) * metrics.widthPixels).toInt() - dp(24)
                y = (mapping.y.coerceIn(0f, 1f) * metrics.heightPixels).toInt() - dp(24)
            }
            try {
                wm.addView(marker, lp)
                hudViews.add(marker)
            } catch (_: Exception) { }
        }
        hudVisible = hudViews.isNotEmpty()
        Toast.makeText(this, if (hudVisible) "HUD exibido sobre outros aplicativos." else "Não foi possível exibir o HUD.", Toast.LENGTH_SHORT).show()
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun hideHud() {
        hudViews.forEach { view -> try { wm.removeView(view) } catch (_: Exception) {} }
        hudViews.clear()
        hudVisible = false
    }

    private fun toggleHud() {
        if (hudVisible) {
            hideHud()
            Toast.makeText(this, "HUD ocultado.", Toast.LENGTH_SHORT).show()
        } else showHud()
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(bg, green, dp(12))
        }
        box.addView(label("GG CARAMELO • CONTROLES", 15f))
        listOf("Mostrar / ocultar HUD", "Atualizar HUD", "Mira: ligar/desligar", "Abrir editor HUD", "Salvar mapeamento", "Fechar menu").forEach { item ->
            val row = label(item, 13f)
            row.setOnClickListener {
                when (item) {
                    "Fechar menu" -> closeMenu()
                    "Mostrar / ocultar HUD" -> { toggleHud(); closeMenu() }
                    "Atualizar HUD" -> { showHud(); closeMenu() }
                    "Mira: ligar/desligar" -> { toggleCrosshair(); closeMenu() }
                    "Abrir editor HUD" -> {
                        val launch = packageManager.getLaunchIntentForPackage(packageName)
                        launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        if (launch != null) startActivity(launch)
                        closeMenu()
                    }
                    "Salvar mapeamento" -> {
                        Toast.makeText(this, "Salve os mapeamentos no editor HUD.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            box.addView(row)
        }
        menu = box
        val lp = params().apply { x = dp(88); y = dp(160); flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE }
        wm.addView(box, lp)
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            try { wm.removeView(crosshair) } catch (_: Exception) {}
            crosshair = null
            Toast.makeText(this, "Mira desativada.", Toast.LENGTH_SHORT).show()
            return
        }
        val view = CrosshairView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, lp)
            crosshair = view
            Toast.makeText(this, "Mira ativada.", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível exibir a mira. Verifique a permissão de sobreposição.", Toast.LENGTH_LONG).show()
        }
    }

    private fun closeMenu() {
        menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        menu = null
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        closeMenu()
        hideHud()
        crosshair?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        crosshair = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
