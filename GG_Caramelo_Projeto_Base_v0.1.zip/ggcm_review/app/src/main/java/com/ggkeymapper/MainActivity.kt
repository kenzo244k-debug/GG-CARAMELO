package com.ggkeymapper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val green = Color.rgb(217, 154, 69)
    private val black = Color.rgb(23, 17, 13)
    private lateinit var editor: HudEditorView
    private lateinit var keyInput: EditText
    private lateinit var profileInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        showEditor()
    }

    private fun showEditor() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(black)
        }
        val title = TextView(this).apply {
            text = "GG CARAMELO  •  EDITOR HUD"
            textSize = 21f; setTextColor(green); gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        status = TextView(this).apply {
            text = "Selecione uma tecla e arraste o marcador para a posição desejada."
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(status)
        editor = HudEditorView(this).apply {
            mappings = MappingStore.load(this@MainActivity)
            if (mappings.isEmpty()) mappings.add(KeyMapping(KeyEvent.KEYCODE_BUTTON_A, .5f, .5f))
            selectedIndex = 0
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        root.addView(editor)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        keyInput = EditText(this).apply {
            hint = "Código da tecla (ex.:  KeyCode 96)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(true)
            setText(editor.mappings.getOrNull(0)?.keyCode?.toString() ?: "")
        }
        controls.addView(keyInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        val add = Button(this).apply {
            text = "ADICIONAR"
            setOnClickListener {
                val code = keyInput.text.toString().toIntOrNull()
                if (code == null) { toast("Digite o código numérico da tecla."); return@setOnClickListener }
                editor.mappings.add(KeyMapping(code, .5f, .5f))
                editor.selectedIndex = editor.mappings.lastIndex
                editor.invalidate()
                status.text = "Tecla $code adicionada. Arraste o marcador."
            }
        }
        controls.addView(add)
        root.addView(controls)

        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        profileInput = EditText(this).apply {
            hint = "Nome do perfil"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(true)
        }
        profileRow.addView(profileInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        profileRow.addView(Button(this).apply {
            text = "SALVAR PERFIL"
            setOnClickListener {
                MappingStore.saveProfile(this@MainActivity, profileInput.text.toString(), editor.mappings)
                toast("Perfil salvo neste aparelho.")
            }
        })
        profileRow.addView(Button(this).apply {
            text = "CARREGAR"
            setOnClickListener { chooseProfile() }
        })
        root.addView(profileRow)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(Button(this).apply {
            text = "SALVAR MAPEAMENTO"
            setOnClickListener {
                val code = keyInput.text.toString().toIntOrNull()
                if (editor.selectedIndex in editor.mappings.indices && code != null) {
                    editor.mappings[editor.selectedIndex] =
                        editor.mappings[editor.selectedIndex].copy(keyCode = code)
                }
                MappingStore.save(this@MainActivity, editor.mappings)
                toast("Mapeamento salvo.")
            }
        })
        actions.addView(Button(this).apply {
            text = "ACESSIBILIDADE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        actions.addView(Button(this).apply {
            text = "ATIVAR BOLINHA"
            setOnClickListener { startOverlay() }
        })
        actions.addView(Button(this).apply {
            text = "REMOVER SELECIONADO"
            setOnClickListener {
                if (editor.selectedIndex in editor.mappings.indices) {
                    editor.mappings.removeAt(editor.selectedIndex)
                    editor.selectedIndex = editor.mappings.lastIndex
                    editor.invalidate()
                    keyInput.setText(editor.mappings.getOrNull(editor.selectedIndex)?.keyCode?.toString() ?: "")
                }
            }
        })
        root.addView(actions)
        val extraRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        extraRow.addView(Button(this).apply {
            text = "MACROS"
            setOnClickListener { showMacros() }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        extraRow.addView(Button(this).apply {
            text = "CONFIGURAÇÕES DO GG"
            setOnClickListener { showSettings() }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(extraRow)
        editor.onSelectionChanged = {
            keyInput.setText(editor.mappings.getOrNull(editor.selectedIndex)?.keyCode?.toString() ?: "")
        }
        setContentView(root)
    }



    /** Editor simples de macros: cada etapa é um toque em coordenadas proporcionais. */
    private fun showMacros() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(black)
        }
        root.addView(TextView(this).apply {
            text = "MACROS DO GG CARAMELO"
            textSize = 22f; setTextColor(green); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(TextView(this).apply {
            text = "Uma macro executa uma sequência de toques quando você pressiona a tecla de atalho."
            textSize = 13f; setTextColor(Color.LTGRAY)
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshList() {
            list.removeAllViews()
            val macros = MacroStore.load(this@MainActivity)
            if (macros.isEmpty()) list.addView(TextView(this@MainActivity).apply {
                text = "Nenhuma macro criada."; setTextColor(Color.LTGRAY); setPadding(4, dp(12), 4, dp(12))
            })
            macros.forEachIndexed { index, macro ->
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(TextView(this@MainActivity).apply {
                    text = "${macro.name} • tecla ${macro.triggerKeyCode} • ${macro.steps.size} etapas"
                    setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                }, LinearLayout.LayoutParams(0, dp(48), 1f))
                row.addView(Button(this@MainActivity).apply {
                    text = "EXCLUIR"
                    setOnClickListener {
                        val updated = MacroStore.load(this@MainActivity).toMutableList()
                        updated.removeAt(index)
                        MacroStore.save(this@MainActivity, updated)
                        refreshList()
                    }
                })
                list.addView(row)
            }
        }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "CRIAR MACRO"
            setOnClickListener { createMacroDialog { refreshList() } }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(Button(this).apply {
            text = "VOLTAR AO EDITOR"
            setOnClickListener { showEditor() }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        refreshList()
        setContentView(root)
    }

    private fun createMacroDialog(onSaved: () -> Unit) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        val name = EditText(this).apply { hint = "Nome da macro"; setSingleLine(true) }
        val trigger = EditText(this).apply {
            hint = "Código da tecla de atalho (ex.: 96)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val sequence = EditText(this).apply {
            hint = "Etapas: x,y,espera_ms; x,y,espera_ms"
            setText("0.50,0.50,120; 0.70,0.60,120")
            minLines = 2
        }
        panel.addView(name); panel.addView(trigger); panel.addView(sequence)
        android.app.AlertDialog.Builder(this)
            .setTitle("Nova macro")
            .setMessage("Coordenadas de 0 a 1. Exemplo: 0.50,0.50,120")
            .setView(panel)
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("SALVAR") { _, _ ->
                val code = trigger.text.toString().toIntOrNull()
                val steps = sequence.text.toString().split(';').mapNotNull { part ->
                    val values = part.trim().split(',')
                    if (values.size < 2) null else {
                        val x = values[0].trim().toFloatOrNull()
                        val y = values[1].trim().toFloatOrNull()
                        val delay = values.getOrNull(2)?.trim()?.toLongOrNull() ?: 120L
                        if (x == null || y == null) null else MacroStep(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f), delay.coerceIn(50L, 5000L))
                    }
                }
                if (code == null || steps.isEmpty()) {
                    toast("Confira a tecla e as etapas da macro.")
                } else {
                    val macros = MacroStore.load(this).toMutableList()
                    macros.removeAll { it.triggerKeyCode == code }
                    macros.add(KeyMacro(name.text.toString().ifBlank { "Macro ${macros.size + 1}" }, code, steps))
                    MacroStore.save(this, macros)
                    toast("Macro salva.")
                    onSaved()
                }
            }.show()
    }

    /** Configurações próprias do GG CARAMELO. */
    private fun showSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(black)
        }
        root.addView(TextView(this).apply {
            text = "CONFIGURAÇÕES DO GG"
            textSize = 22f
            setTextColor(green)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(54)))

        root.addView(TextView(this).apply {
            text = "Ajustes do mapeamento e dos controles."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(42)))

        val precision = Switch(this).apply {
            text = "Modo Precisão"
            textSize = 17f
            setTextColor(Color.WHITE)
            isChecked = MappingStore.isPrecisionModeEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, enabled ->
                MappingStore.setPrecisionModeEnabled(this@MainActivity, enabled)
                toast(if (enabled) "Modo Precisão ativado." else "Modo Precisão desativado.")
            }
        }
        root.addView(precision, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(TextView(this).apply {
            text = "Quando ativado, o mapeamento usa arredondamento para coordenadas inteiras da tela."
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(-1, dp(48)))

        root.addView(Button(this).apply {
            text = "VOLTAR AO EDITOR"
            setOnClickListener { showEditor() }
        }, LinearLayout.LayoutParams(-1, dp(50)))
        setContentView(root)
    }

    private fun chooseProfile() {
        val names = MappingStore.profileNames(this)
        if (names.isEmpty()) { toast("Nenhum perfil salvo."); return }
        android.app.AlertDialog.Builder(this)
            .setTitle("Carregar perfil")
            .setItems(names.toTypedArray()) { _, which ->
                val loaded = MappingStore.loadProfile(this, names[which])
                if (loaded != null) {
                    editor.mappings = loaded
                    editor.selectedIndex = if (loaded.isEmpty()) -1 else 0
                    editor.invalidate()
                    keyInput.setText(loaded.firstOrNull()?.keyCode?.toString() ?: "")
                    toast("Perfil carregado.")
                }
            }.show()
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, OverlayService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
