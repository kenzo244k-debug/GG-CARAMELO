package com.ggkeymapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Mira simples desenhada pelo próprio app; não altera o jogo nem injeta comandos. */
class CrosshairView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(217, 154, 69)
        strokeWidth = 2.5f * resources.displayMetrics.density
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val d = 13f * resources.displayMetrics.density
        val gap = 5f * resources.displayMetrics.density
        canvas.drawLine(cx - d, cy, cx - gap, cy, paint)
        canvas.drawLine(cx + gap, cy, cx + d, cy, paint)
        canvas.drawLine(cx, cy - d, cx, cy - gap, paint)
        canvas.drawLine(cx, cy + gap, cx, cy + d, paint)
        canvas.drawCircle(cx, cy, 2f * resources.displayMetrics.density, paint)
    }
}
